"""A population after every row has been scored."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .evaluator import ModelEvaluator
from .records import ModelMetrics


@dataclass(frozen=True, eq=False)
class ScoredPopulation:
    rows: np.ndarray                # (population_size, n_features) of 0/1
    metrics: list[ModelMetrics]     # one per row
    fitness: np.ndarray             # one per row, lower is better
    order: np.ndarray               # row numbers sorted from best to worst fitness

    @classmethod
    def score(cls, rows: np.ndarray, evaluator: ModelEvaluator) -> "ScoredPopulation":
        metrics = [evaluator.evaluate(np.flatnonzero(row)) for row in rows]
        fitness = np.array([m.fitness for m in metrics])
        order = np.argsort(fitness, kind="stable")
        return cls(rows=rows, metrics=metrics, fitness=fitness, order=order)

    @property
    def best_row(self) -> int:
        return int(self.order[0])

    @property
    def best_fitness(self) -> float:
        return self.fitness[self.best_row]

    @property
    def mean_fitness(self) -> float:
        """Mean over the rows that could be fitted (NaN if there are none)."""
        finite = np.isfinite(self.fitness)
        return self.fitness[finite].mean() if finite.any() else np.nan

    @property
    def n_valid(self) -> int:
        return int(np.isfinite(self.fitness).sum())

    @property
    def n_passing(self) -> int:
        return sum(m.passes for m in self.metrics)

    def columns_of(self, row_number: int) -> np.ndarray:
        """Descriptor column numbers used by one row."""
        return np.flatnonzero(self.rows[row_number])
