"""The genetic algorithm itself: the generation loop."""

from __future__ import annotations

import time
from collections.abc import Callable

import numpy as np

from .breeding import NextGenerationBuilder
from .config import GAConfig
from .data import Dataset
from .evaluator import ModelEvaluator
from .operators import NPointCrossover, RandomRowFactory, SwitchMutation
from .population import ScoredPopulation
from .records import GAResult, GenerationRecord
from .tracking import BestModelTracker, RunHistory

ProgressCallback = Callable[[GenerationRecord], None]


class GeneticAlgorithm:
    """Score the population, remember the best models, breed, repeat.

    Build it with ``GeneticAlgorithm.from_config(config, dataset)``, or pass your
    own evaluator / row factory / builder to the constructor to swap a piece.
    """

    def __init__(
        self,
        config: GAConfig,
        evaluator: ModelEvaluator,
        row_factory: RandomRowFactory,
        builder: NextGenerationBuilder,
        progress: ProgressCallback | None = None,
    ):
        self._config = config
        self._evaluator = evaluator
        self._row_factory = row_factory
        self._builder = builder
        self._progress = progress

    @classmethod
    def from_config(
        cls,
        config: GAConfig,
        dataset: Dataset,
        progress: ProgressCallback | None = None,
    ) -> "GeneticAlgorithm":
        rng = np.random.default_rng(config.random_seed)
        evaluator = ModelEvaluator(dataset, config)
        row_factory = RandomRowFactory(dataset.n_features, config.p_select, rng)
        crossover = NPointCrossover(config.n_cuts, dataset.n_features, rng)
        mutation = SwitchMutation(config.mutations_per_child, rng)
        builder = NextGenerationBuilder(config, row_factory, crossover, mutation, rng)
        return cls(config, evaluator, row_factory, builder, progress)

    @property
    def evaluator(self) -> ModelEvaluator:
        return self._evaluator

    def run(self) -> GAResult:
        config = self._config
        tracker = BestModelTracker()
        history = RunHistory()

        start_time = time.time()
        rows = self._row_factory.make(config.population_size)

        for generation in range(config.n_generations + 1):
            scored = ScoredPopulation.score(rows, self._evaluator)
            tracker.update(generation, scored)
            record = history.record(generation, scored, tracker.best_passing)
            if self._progress is not None:
                self._progress(record)

            if generation < config.n_generations:
                rows = self._builder.build(scored.rows, scored.order)

        best = tracker.best()
        return GAResult(
            best=best,
            passed_rule=tracker.passed_rule,
            history=history.to_dataframe(),
            final_model=self._evaluator.fit(best.columns),
            elapsed_seconds=time.time() - start_time,
        )
