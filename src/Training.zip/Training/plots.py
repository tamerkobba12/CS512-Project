"""Plots (optional: skipped if matplotlib is not installed)."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def _pyplot():
    """matplotlib.pyplot with a file-only backend, or None if matplotlib is missing."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib is not installed, so the plots were skipped.")
        return None
    return plt


def save_diagnostic_plots(history: pd.DataFrame, predictions: pd.DataFrame, path: Path) -> bool:
    """Left: fitness per generation. Right: actual vs predicted pIC50.

    Returns True if the picture was saved.
    """
    plt = _pyplot()
    if plt is None:
        return False

    figure, (left, right) = plt.subplots(1, 2, figsize=(12, 4.5))

    left.plot(history["generation"], history["best_fitness"], label="best fitness")
    left.plot(history["generation"], history["mean_fitness"], label="mean fitness", alpha=0.6)
    left.set_xlabel("generation")
    left.set_ylabel("fitness (lower is better)")
    left.legend()

    # Each dot is one molecule. The dashed line is NOT a fitted model: it only marks
    # where predicted = actual. Above it the model over-predicted, below it under-predicted.
    for name, color in (("train", "tab:blue"), ("validation", "tab:orange"), ("test", "tab:green")):
        part = predictions[predictions["set"] == name]
        actual, predicted = part["actual"].to_numpy(), part["predicted"].to_numpy()
        r2 = 1.0 - np.sum((actual - predicted) ** 2) / np.sum((actual - actual.mean()) ** 2)
        rmse = np.sqrt(np.mean((actual - predicted) ** 2))
        right.scatter(actual, predicted, s=14, alpha=0.7, color=color,
                      label=f"{name} (R² = {r2:.2f}, RMSE = {rmse:.2f})")
    low = predictions[["actual", "predicted"]].min().min()
    high = predictions[["actual", "predicted"]].max().max()
    right.plot([low, high], [low, high], color="gray", linewidth=1, linestyle="--",
               label="perfect prediction (predicted = actual)")

    # Point out the single largest error, whatever set it is in.
    errors = np.abs(predictions["predicted"].to_numpy() - predictions["actual"].to_numpy())
    worst = predictions.iloc[int(np.argmax(errors))]
    on_left = worst["actual"] < (low + high) / 2
    right.annotate(
        f"largest error ({worst['set']}):\nactual {worst['actual']:.1f}, predicted {worst['predicted']:.1f}",
        xy=(worst["actual"], worst["predicted"]),
        xytext=(25 if on_left else -25, 0), textcoords="offset points",
        ha="left" if on_left else "right", va="center", fontsize=8,
        bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "edgecolor": "gray",
              "linewidth": 0.5, "alpha": 0.9},
        arrowprops={"arrowstyle": "->", "color": "black", "linewidth": 0.8},
    )

    right.set_title("Predicted vs actual pIC50 (one dot = one molecule)\n"
                    "above the dashed line = over-predicted, below = under-predicted", fontsize=9)
    right.set_xlabel("actual pIC50 (measured)")
    right.set_ylabel("predicted pIC50 (from the model)")
    right.legend(loc="lower right", fontsize=8)

    figure.tight_layout()
    figure.savefig(path, dpi=150)
    plt.close(figure)
    return True


def save_metrics_plot(metrics: pd.DataFrame, passed: bool, r2_min: float, r2_max: float,
                      path: Path) -> bool:
    """Left: R2 and Q2 for each set. Right: RMSE for each set.

    metrics: rows R2 / Q2 (leave-one-out) / RMSE, columns Training / Validation / Test.
    """
    plt = _pyplot()
    if plt is None:
        return False

    sets = list(metrics.columns)
    x = np.arange(len(sets))
    width = 0.36
    figure, (left, right) = plt.subplots(1, 2, figsize=(12, 4.5), gridspec_kw={"width_ratios": [1.3, 1]})

    def label(axis, bars, values):
        for bar, value in zip(bars, values):
            axis.text(bar.get_x() + bar.get_width() / 2, value, f"{value:.2f}",
                      ha="center", va="bottom", fontsize=9,
                      bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.85, "pad": 1.5})

    r2 = metrics.loc["R2"].to_numpy(dtype=float)
    label(left, left.bar(x - width / 2, r2, width, color="tab:blue", label="R²"), r2)
    q2 = metrics.loc["Q2 (leave-one-out)"].to_numpy(dtype=float)
    has_q2 = ~np.isnan(q2)
    q2_bars = left.bar(x[has_q2] + width / 2, q2[has_q2], width, color="tab:orange",
                       label="Q² (leave-one-out, training only)")
    label(left, q2_bars, q2[has_q2])
    left.axhline(r2_min, color="black", linestyle="--", linewidth=1, label=f"rule: at least {r2_min:g}")
    left.axhline(r2_max, color="black", linestyle=":", linewidth=1, label=f"rule: below {r2_max:g}")
    left.set_xticks(x)
    left.set_xticklabels(sets)
    left.set_ylim(min(0.0, float(np.nanmin(metrics.loc[["R2", "Q2 (leave-one-out)"]].to_numpy(dtype=float)))) - 0.05,
                  r2_max + 0.3)
    left.set_ylabel("value")
    left.set_title(f"R² and Q²   (rule on R² train, Q² train, R² validation, R² test: "
                   f"{'PASS' if passed else 'FAIL'})", fontsize=10)
    left.legend(loc="upper center", ncol=2, fontsize=8)

    rmse = metrics.loc["RMSE"].to_numpy(dtype=float)
    label(right, right.bar(x, rmse, 0.5, color="tab:blue"), rmse)
    right.set_xticks(x)
    right.set_xticklabels(sets)
    right.set_ylim(0, rmse.max() * 1.15)
    right.set_ylabel("pIC50 units")
    right.set_title("RMSE (lower is better)", fontsize=10)

    figure.tight_layout()
    figure.savefig(path, dpi=150)
    plt.close(figure)
    return True