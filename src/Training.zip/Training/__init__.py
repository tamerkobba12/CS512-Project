"""Genetic algorithm for feature selection (QSAR project).

Goal: out of all molecular descriptors (X), find a SMALL subset that gives a
linear regression model that predicts pIC50 (Y) well on unseen molecules.

How it works
------------
* A "model" is one row of 0s and 1s, one entry per descriptor (1 = use it).
* The "population" is 50 such rows.
* Each row is scored ("fitness") by fitting a linear regression on the TRAINING
  molecules with only its descriptors (see ``FitnessMode`` for the options;
  lower is better).
* Every generation: copy the best two rows unchanged, make children from the
  3rd and 4th best rows (crossover), nudge the children (mutation), repeat.
* The winner is the lowest-fitness model whose R2/Q2 values all pass the
  professor's rule: training R2, training Q2, validation R2 and test R2 are
  each >= 0.5 and < 1.

Where things live
-----------------
config.py     GAConfig, FitnessMode        every setting
data.py       Dataset                      the six CSV files
records.py    ModelMetrics, FoundModel...  small containers
evaluator.py  ModelEvaluator               fit one model, compute R2/Q2/RMSE/fitness
operators.py  RandomRowFactory, NPointCrossover, SwitchMutation
population.py ScoredPopulation             a scored, ranked population
breeding.py   NextGenerationBuilder        elitism + children (+ random rows)
tracking.py   BestModelTracker, RunHistory best models and the per-generation log
algorithm.py  GeneticAlgorithm             the generation loop
checks.py     verify_fast_q2               self-check of the Q2 shortcut
reporting.py  ProgressPrinter, ResultsReporter   console output and result files
summary.py    ModelSummary                 metrics table: R2, Q2, RMSE per set
plots.py      save_diagnostic_plots, save_metrics_plot   optional matplotlib figures
__main__.py   main()                       wires everything together
"""

from .algorithm import GeneticAlgorithm
from .config import FitnessMode, GAConfig
from .data import Dataset
from .evaluator import ModelEvaluator
from .records import GAResult, ModelMetrics

__all__ = [
    "Dataset",
    "FitnessMode",
    "GAConfig",
    "GAResult",
    "GeneticAlgorithm",
    "ModelEvaluator",
    "ModelMetrics",
]
