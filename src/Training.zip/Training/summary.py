"""The model's metrics as one table: R2, Q2 and RMSE for training, validation and test."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .config import GAConfig
from .records import GAResult


class ModelSummary:
    """The metrics of the best model."""

    def __init__(self, config: GAConfig, result: GAResult):
        self._config = config
        self._result = result

    @property
    def passed_rule(self) -> bool:
        """Professor's rule: R2 train, Q2 train, R2 validation and R2 test all in range."""
        return self._result.passed_rule

    def metrics_table(self) -> pd.DataFrame:
        """Rows = R2 / Q2 / RMSE, columns = Training / Validation / Test.

        Q2 is the leave-one-out value, which only exists for the training set (NaN elsewhere).
        """
        m = self._result.best.metrics
        return pd.DataFrame(
            {
                "Training": [m.r2_train, m.q2_train, m.rmse_train],
                "Validation": [m.r2_valid, np.nan, m.rmse_valid],
                "Test": [m.r2_test, np.nan, m.rmse_test],
            },
            index=["R2", "Q2 (leave-one-out)", "RMSE"],
        )

    def print_all(self) -> None:
        cfg, best = self._config, self._result.best
        table = self.metrics_table().map(lambda v: "-" if pd.isna(v) else f"{v:.3f}")

        print("\n" + "=" * 60)
        print("BEST MODEL" if self.passed_rule else "NO MODEL PASSED THE RULE - lowest-fitness model shown")
        print("=" * 60)
        print(f"Found in generation {best.generation} | {len(best.columns)} descriptors")
        print(f"Rule (R2 train, Q2 train, R2 validation, R2 test all >= {cfg.r2_min:g} and "
              f"< {cfg.r2_max:g}): {'PASS' if self.passed_rule else 'FAIL'}\n")
        print(table.to_string())