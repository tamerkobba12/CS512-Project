"""Self-check: is the fast Q2 formula right?"""

from __future__ import annotations

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import LeaveOneOut, cross_val_predict

from .data import Dataset
from .evaluator import ModelEvaluator


def verify_fast_q2(
    evaluator: ModelEvaluator,
    dataset: Dataset,
    n_models: int = 5,
    n_descriptors: int = 8,
    seed: int = 0,
    tolerance: float = 1e-8,
) -> float:
    """Compare the evaluator's leave-one-out shortcut with sklearn's slow version.

    Uses its own random generator, so it never changes the GA's random numbers.
    Returns the largest difference found; raises RuntimeError if it is too big.
    """
    rng = np.random.default_rng(seed)
    y = dataset.y_train
    total = np.sum((y - y.mean()) ** 2)

    largest_difference = 0.0
    checked = 0
    for _ in range(n_models):
        columns = rng.choice(dataset.n_features, n_descriptors, replace=False)
        fast_q2 = evaluator.evaluate(columns).q2_train
        if np.isnan(fast_q2):
            continue
        slow_pred = cross_val_predict(
            LinearRegression(), dataset.X_train[:, columns], y, cv=LeaveOneOut()
        )
        slow_q2 = 1.0 - np.sum((y - slow_pred) ** 2) / total
        largest_difference = max(largest_difference, abs(fast_q2 - slow_q2))
        checked += 1

    print(f"\nSelf-check: fast Q2 vs sklearn leave-one-out on {checked} random models,"
          f" largest difference = {largest_difference:.2e}")
    if largest_difference >= tolerance:
        raise RuntimeError("Q2 shortcut does not match sklearn!")
    return largest_difference
