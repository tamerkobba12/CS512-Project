"""Loading the six files made by preprocessing.py."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd


@dataclass(frozen=True, eq=False)
class Dataset:
    """Training, validation and test molecules as numpy arrays.

    X = molecular descriptors (one column each), y = pIC50.
    """

    X_train: np.ndarray
    X_valid: np.ndarray
    X_test: np.ndarray
    y_train: np.ndarray
    y_valid: np.ndarray
    y_test: np.ndarray
    feature_names: np.ndarray

    @property
    def n_train(self) -> int:
        return self.X_train.shape[0]

    @property
    def n_features(self) -> int:
        return self.X_train.shape[1]

    @classmethod
    def from_folder(cls, folder: Path | str) -> "Dataset":
        """Read TrainX/ValidX/TestX and TrainY/ValidY/TestY (.csv) from ``folder``."""
        folder = Path(folder)

        X_train_df = pd.read_csv(folder / "TrainX.csv")
        X_valid_df = pd.read_csv(folder / "ValidX.csv")
        X_test_df = pd.read_csv(folder / "TestX.csv")

        return cls(
            X_train=X_train_df.to_numpy(),
            X_valid=X_valid_df.to_numpy(),
            X_test=X_test_df.to_numpy(),
            y_train=pd.read_csv(folder / "TrainY.csv").iloc[:, 0].to_numpy(),
            y_valid=pd.read_csv(folder / "ValidY.csv").iloc[:, 0].to_numpy(),
            y_test=pd.read_csv(folder / "TestY.csv").iloc[:, 0].to_numpy(),
            feature_names=np.array(X_train_df.columns),
        )

    def print_shapes(self) -> None:
        print("Training  :", self.X_train.shape)
        print("Validation:", self.X_valid.shape)
        print("Test      :", self.X_test.shape)
