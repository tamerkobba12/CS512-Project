"""Small data containers passed between the other modules."""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression


@dataclass(frozen=True)
class ModelMetrics:
    """Everything we know about one model (one row of the population).

    R2  = how much of the variation in Y the model explains
          (1 = perfect, 0 = no better than predicting the average).
    Q2  = like R2, but "leave-one-out": every training molecule is predicted by
          a model that never saw it.
    RMSE = typical size of the prediction error, in pIC50 units.
    """

    n_features: int
    r2_train: float
    q2_train: float
    r2_valid: float
    r2_test: float
    rmse_train: float
    rmse_cv_train: float
    rmse_valid: float
    rmse_test: float
    fitness: float          # lower is better
    passes: bool            # passes the professor's R2/Q2 rule

    @classmethod
    def invalid(cls, n_features: int) -> "ModelMetrics":
        """Result for a model that cannot be fitted (fitness = infinity)."""
        nan = np.nan
        return cls(
            n_features=n_features,
            r2_train=nan, q2_train=nan, r2_valid=nan, r2_test=nan,
            rmse_train=nan, rmse_cv_train=nan, rmse_valid=nan, rmse_test=nan,
            fitness=np.inf, passes=False,
        )

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, eq=False)
class FoundModel:
    """A model worth remembering, and the generation it was found in."""

    generation: int
    columns: np.ndarray     # descriptor column numbers
    metrics: ModelMetrics


@dataclass(frozen=True)
class GenerationRecord:
    """One line of the history log."""

    generation: int
    best_fitness: float
    mean_fitness: float
    valid_models: int
    passing_models: int
    best_passing_fitness: float


@dataclass(frozen=True, eq=False)
class GAResult:
    """What GeneticAlgorithm.run() returns."""

    best: FoundModel
    passed_rule: bool           # False -> `best` is only the lowest-fitness fallback
    history: pd.DataFrame       # one row per generation
    final_model: LinearRegression
    elapsed_seconds: float
