"""Building the next generation from the current one."""

from __future__ import annotations

from collections.abc import Callable

import numpy as np

from .config import GAConfig
from .operators import RandomRowFactory

Crossover = Callable[[np.ndarray, np.ndarray], tuple[np.ndarray, np.ndarray]]
Mutation = Callable[[np.ndarray], np.ndarray]


class NextGenerationBuilder:
    """Elitism + children of the chosen parents (+ optional random rows).

    1. The best ``n_elite`` rows are copied unchanged.
    2. Children of the rows at ``parent_ranks`` (3rd and 4th best by default)
       fill the rows after them, each child mutated.
    3. The last ``n_random_rows`` rows are brand-new random rows.
    """

    def __init__(
        self,
        config: GAConfig,
        row_factory: RandomRowFactory,
        crossover: Crossover,
        mutation: Mutation,
        rng: np.random.Generator,
    ):
        self._population_size = config.population_size
        self._n_elite = config.n_elite
        # a numpy array, because a tuple would be read as a multi-dimensional index
        self._parent_ranks = np.array(config.parent_ranks)
        self._n_random_rows = config.n_random_rows
        self._row_factory = row_factory
        self._crossover = crossover
        self._mutation = mutation
        self._rng = rng

    def build(self, population: np.ndarray, order: np.ndarray) -> np.ndarray:
        """population: current rows. order: row numbers from best to worst."""
        next_population = np.zeros_like(population)

        next_population[: self._n_elite] = population[order[: self._n_elite]]

        parents = population[order[self._parent_ranks]]
        last_child_row = self._population_size - self._n_random_rows
        row = self._n_elite
        while row < last_child_row:
            i, j = self._rng.choice(len(parents), 2, replace=False)
            child_1, child_2 = self._crossover(parents[i], parents[j])
            for child in (child_1, child_2):
                if row < last_child_row:
                    next_population[row] = self._mutation(child)
                    row += 1

        if self._n_random_rows > 0:
            next_population[last_child_row:] = self._row_factory.make(self._n_random_rows)

        return next_population
