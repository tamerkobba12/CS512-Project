"""Remembering the best models and logging every generation."""

from __future__ import annotations

from dataclasses import asdict

import numpy as np
import pandas as pd

from .population import ScoredPopulation
from .records import FoundModel, GenerationRecord


class BestModelTracker:
    """Keeps the best models seen in any generation.

    * best_passing : lowest fitness among models that pass the R2/Q2 rule
    * best_overall : lowest fitness of all (fallback if nothing ever passes)
    """

    def __init__(self) -> None:
        self.best_overall: FoundModel | None = None
        self.best_passing: FoundModel | None = None

    def update(self, generation: int, scored: ScoredPopulation) -> None:
        top = scored.metrics[scored.best_row]
        if np.isfinite(top.fitness) and (
                self.best_overall is None or top.fitness < self.best_overall.metrics.fitness):
            self.best_overall = FoundModel(generation, scored.columns_of(scored.best_row), top)

        for row_number in scored.order:         # first passing row = lowest fitness
            metrics = scored.metrics[row_number]
            if metrics.passes:
                if self.best_passing is None or metrics.fitness < self.best_passing.metrics.fitness:
                    self.best_passing = FoundModel(
                        generation, scored.columns_of(row_number), metrics)
                break

    @property
    def passed_rule(self) -> bool:
        return self.best_passing is not None

    def best(self) -> FoundModel:
        """The passing model if there is one, otherwise the lowest-fitness model."""
        chosen = self.best_passing if self.passed_rule else self.best_overall
        if chosen is None:
            raise RuntimeError(
                "No model could be fitted in any generation. Check p_select and the data.")
        return chosen


class RunHistory:
    """One GenerationRecord per generation."""

    def __init__(self) -> None:
        self._records: list[GenerationRecord] = []

    def record(
        self,
        generation: int,
        scored: ScoredPopulation,
        best_passing: FoundModel | None,
    ) -> GenerationRecord:
        record = GenerationRecord(
            generation=generation,
            best_fitness=scored.best_fitness,
            mean_fitness=scored.mean_fitness,
            valid_models=scored.n_valid,
            passing_models=scored.n_passing,
            best_passing_fitness=(
                best_passing.metrics.fitness if best_passing is not None else np.nan),
        )
        self._records.append(record)
        return record

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame([asdict(r) for r in self._records])
