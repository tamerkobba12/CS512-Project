"""Console output and the files written to results/ (CSV tables and PNG plots)."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .config import GAConfig
from .data import Dataset
from .plots import save_diagnostic_plots, save_metrics_plot
from .records import GAResult, GenerationRecord
from .summary import ModelSummary


class ProgressPrinter:
    """Prints one progress line every ``every`` generations (and the last one)."""

    def __init__(self, every: int, last_generation: int):
        self._every = every
        self._last_generation = last_generation

    def __call__(self, record: GenerationRecord) -> None:
        if record.generation % self._every == 0 or record.generation == self._last_generation:
            print(f"generation {record.generation:4d} | best fitness {record.best_fitness:.4f}"
                  f" | mean {record.mean_fitness:.4f} | passing models {record.passing_models:2d}"
                  f" | best passing {record.best_passing_fitness:.4f}")


class ResultsReporter:
    """Prints the best model and saves every output file."""

    def __init__(self, config: GAConfig, dataset: Dataset, result: GAResult):
        self._config = config
        self._data = dataset
        self._result = result

    # ------------------------------------------------------------------
    def coefficients(self) -> pd.DataFrame:
        """Descriptors of the best model, largest coefficient first."""
        columns = self._result.best.columns
        return pd.DataFrame({
            "descriptor": self._data.feature_names[columns],
            "column_number": columns,
            "coefficient": self._result.final_model.coef_,
        }).sort_values("coefficient", key=np.abs, ascending=False)

    def predictions(self) -> pd.DataFrame:
        """Actual and predicted pIC50 for every molecule, labelled by set."""
        data, model = self._data, self._result.final_model
        columns = self._result.best.columns
        parts = [
            pd.DataFrame({"set": name, "actual": y, "predicted": model.predict(X[:, columns])})
            for name, X, y in (
                ("train", data.X_train, data.y_train),
                ("validation", data.X_valid, data.y_valid),
                ("test", data.X_test, data.y_test),
            )
        ]
        return pd.concat(parts)

    def summary(self) -> ModelSummary:
        return ModelSummary(self._config, self._result)

    # ------------------------------------------------------------------
    def print_summary(self) -> None:
        self.summary().print_all()

    def save(self, out_dir: Path | str | None = None) -> Path:
        """Write the CSV tables and the PNG plots. Returns the output folder."""
        result, cfg = self._result, self._config
        out = Path(out_dir) if out_dir is not None else cfg.results_dir
        out.mkdir(parents=True, exist_ok=True)
        summary = self.summary()
        predictions = self.predictions()
        metrics = summary.metrics_table()

        # --- the metrics: R2, Q2, RMSE for training / validation / test ---
        metrics.round(4).to_csv(out / "best_model_summary.csv", index_label="metric")
        save_metrics_plot(metrics, summary.passed_rule, cfg.r2_min, cfg.r2_max, out / "metrics_plot.png")

        # --- the rest of the run ---
        result.history.to_csv(out / "ga_history.csv", index=False)
        intercept_row = pd.DataFrame({
            "descriptor": ["(intercept)"],
            "column_number": [-1],
            "coefficient": [result.final_model.intercept_],
        })
        pd.concat([self.coefficients(), intercept_row], ignore_index=True).to_csv(
            out / "best_model_features.csv", index=False)
        metrics_row = {
            **result.best.metrics.to_dict(),
            "found_in_generation": result.best.generation,
            "passes_rule": result.passed_rule,
        }
        pd.DataFrame([metrics_row]).to_csv(out / "best_model_metrics.csv", index=False)
        predictions.to_csv(out / "best_model_predictions.csv", index=False)
        save_diagnostic_plots(result.history, predictions, out / "ga_plots.png")

        print("\nSaved results to:", out)
        return out
