"""The genetic operators: random rows, crossover and mutation.

A "row" is a 0/1 numpy array with one entry per descriptor (1 = use it).
Every operator gets the shared random generator, so one seed controls the run.
"""

from __future__ import annotations

import numpy as np


class RandomRowFactory:
    """Makes random 0/1 rows. Each descriptor is 1 with probability p_select."""

    def __init__(self, n_features: int, p_select: float, rng: np.random.Generator):
        self._n_features = n_features
        self._p_select = p_select
        self._rng = rng

    def make(self, n_rows: int) -> np.ndarray:
        rows = (self._rng.random((n_rows, self._n_features)) < self._p_select).astype(np.int8)
        for row in rows:
            if row.sum() == 0:                              # never allow an empty model
                row[self._rng.integers(self._n_features)] = 1
        return rows


class NPointCrossover:
    """Cut both parents at the same random places and swap the pieces.

    one-point:  child 1 = mom's left part + dad's right part
                child 2 = dad's left part + mom's right part
    """

    def __init__(self, n_cuts: int, n_features: int, rng: np.random.Generator):
        if n_cuts > n_features - 1:
            raise ValueError(f"cannot make {n_cuts} cuts in {n_features} descriptors")
        self._n_cuts = n_cuts
        self._n_features = n_features
        self._rng = rng

    def __call__(self, mom: np.ndarray, dad: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        n = self._n_features
        cut_positions = np.sort(self._rng.choice(np.arange(1, n), self._n_cuts, replace=False))

        take_from_dad = np.zeros(n, dtype=bool)
        use_dad = False
        start = 0
        for cut in list(cut_positions) + [n]:
            take_from_dad[start:cut] = use_dad
            use_dad = not use_dad
            start = cut

        child_1 = np.where(take_from_dad, dad, mom).astype(np.int8)
        child_2 = np.where(take_from_dad, mom, dad).astype(np.int8)
        return child_1, child_2


class SwitchMutation:
    """Flip a few random 0/1 values in a child.

    Half the time a descriptor that is on is switched OFF; half the time one
    that is off is switched ON. (A plain random flip would almost always turn a
    descriptor on, because most entries are 0.)
    """

    def __init__(self, n_mutations: int, rng: np.random.Generator):
        self._n_mutations = n_mutations
        self._rng = rng

    def __call__(self, child: np.ndarray) -> np.ndarray:
        child = child.copy()
        for _ in range(self._n_mutations):
            selected = np.flatnonzero(child == 1)
            not_selected = np.flatnonzero(child == 0)
            if self._rng.random() < 0.5 and len(selected) > 1:
                child[self._rng.choice(selected)] = 0
            else:
                child[self._rng.choice(not_selected)] = 1
        return child
