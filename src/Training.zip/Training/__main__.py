"""Run with:  python -m ga_qsar   (from the folder that contains ga_qsar/)."""

from __future__ import annotations

from .algorithm import GeneticAlgorithm
from .checks import verify_fast_q2
from .config import GAConfig
from .data import Dataset
from .records import GAResult
from .reporting import ProgressPrinter, ResultsReporter


def main(config: GAConfig | None = None) -> GAResult:
    config = config or GAConfig()       # e.g. GAConfig(n_generations=100, n_cuts=2)

    dataset = Dataset.from_folder(config.data_dir)
    dataset.print_shapes()

    algorithm = GeneticAlgorithm.from_config(
        config, dataset,
        progress=ProgressPrinter(config.print_every, config.n_generations),
    )

    if config.run_self_check:
        verify_fast_q2(algorithm.evaluator, dataset)

    print("\nRunning the genetic algorithm...")
    result = algorithm.run()
    print(f"\nFinished in {result.elapsed_seconds:.1f} seconds.")

    reporter = ResultsReporter(config, dataset, result)
    reporter.print_summary()
    reporter.save()
    return result


if __name__ == "__main__":
    main()
