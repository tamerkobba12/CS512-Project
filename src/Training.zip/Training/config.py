"""All tunable settings in one place.

Change the defaults below, or build your own config in ``__main__.py``:

    GAConfig(n_generations=100, n_cuts=2)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path

def _find_project_root() -> Path:
    """The folder that contains data/processed/ (and where results/ is created).

    Looks upward from this package, so it works whether ga_qsar/ sits directly
    in the project folder or inside a src/ folder.
    """
    here = Path(__file__).resolve().parent
    for folder in (here, *here.parents):
        if (folder / "data" / "processed").is_dir():
            return folder
    return here.parent      # not found: the error will show where it looked


PROJECT_ROOT = _find_project_root()


class FitnessMode(str, Enum):
    """What "fitness" means. Lower is better; all are errors in pIC50 units."""

    # Average of the training leave-one-out RMSE and the validation RMSE (default).
    # The validation set helps choose the model, so the TEST set is the only
    # fair estimate of how well it predicts new molecules.
    TRAIN_VALID = "train_valid"

    # Training leave-one-out RMSE only. Validation and test stay completely
    # unseen, but the GA then finds weaker models.
    CV_TRAIN = "cv_train"

    # Validation RMSE only. NOT recommended: the GA overfits the validation
    # molecules (in earlier tests validation R2 was 0.96 while test R2 was negative).
    VALID = "valid"


@dataclass(frozen=True)
class GAConfig:
    # --- population ---------------------------------------------------------
    population_size: int = 50       # number of models (rows) per generation
    n_generations: int = 500        # how many generations to run
    random_seed: int = 42           # same seed -> same results every run

    # Initial population: chance that a descriptor is selected (professor: 1.5%).
    # Expected descriptors per starting model = p_select * number of descriptors
    # (about 6 when there are 385). Lower it if models overfit.
    p_select: float = 0.015

    # --- how the next generation is built -----------------------------------
    n_elite: int = 2                          # best rows copied unchanged
    parent_ranks: tuple[int, ...] = (2, 3)    # parents = 3rd and 4th best (0 = best).
                                              # For more variety: tuple(range(2, 12))
    n_cuts: int = 1                           # crossover: 1 = one-point, 2 = two-point, ...
    mutations_per_child: int = 1              # random changes applied to every child
    n_random_rows: int = 0                    # brand-new random rows added each generation

    # --- professor's rule: all four R2/Q2 values must be >= r2_min and < r2_max
    r2_min: float = 0.65
    r2_max: float = 1.0

    fitness_mode: FitnessMode = FitnessMode.CV_TRAIN

    # --- run and output -----------------------------------------------------
    run_self_check: bool = True     # compare the fast Q2 formula with sklearn's slow one
    print_every: int = 25           # progress line every N generations
    data_dir: Path = PROJECT_ROOT / "data" / "processed"
    results_dir: Path = PROJECT_ROOT / "results"

    def __post_init__(self) -> None:
        # Accept plain strings / lists and normalise them.
        object.__setattr__(self, "fitness_mode", FitnessMode(self.fitness_mode))
        object.__setattr__(self, "parent_ranks", tuple(self.parent_ranks))
        object.__setattr__(self, "data_dir", Path(self.data_dir))
        object.__setattr__(self, "results_dir", Path(self.results_dir))

        if self.population_size < 1:
            raise ValueError("population_size must be at least 1")
        if not 0 < self.p_select <= 1:
            raise ValueError("p_select must be in (0, 1]")
        if self.n_elite < 0 or self.n_random_rows < 0:
            raise ValueError("n_elite and n_random_rows cannot be negative")
        if self.n_elite + self.n_random_rows > self.population_size:
            raise ValueError("n_elite + n_random_rows cannot exceed population_size")
        if len(self.parent_ranks) < 2:
            raise ValueError("parent_ranks needs at least two ranks")
        if any(not 0 <= rank < self.population_size for rank in self.parent_ranks):
            raise ValueError("every parent rank must be between 0 and population_size - 1")
        if self.n_cuts < 1:
            raise ValueError("n_cuts must be at least 1")
        if self.mutations_per_child < 0:
            raise ValueError("mutations_per_child cannot be negative")
        if self.print_every < 1:
            raise ValueError("print_every must be at least 1")