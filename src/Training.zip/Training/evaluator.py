"""Scoring one model: fit a linear regression and compute R2, Q2, RMSE, fitness."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

from .config import FitnessMode, GAConfig
from .data import Dataset
from .records import ModelMetrics


class ModelEvaluator:
    """Evaluates a model given as a list of descriptor column numbers.

    Fitness is set by ``config.fitness_mode`` (lower is better). Plain training
    error is never used, because it always improves when you add descriptors,
    which rewards overfitting.
    """

    RANK_TOLERANCE = 1e-8        # singular values below max * this count as zero
    LEVERAGE_TOLERANCE = 1e-8    # reject a model if 1 - leverage is below this
    SPARE_MOLECULES = 2          # need clearly fewer descriptors than molecules

    def __init__(self, dataset: Dataset, config: GAConfig):
        self._data = dataset
        self._config = config

    # ------------------------------------------------------------------
    def evaluate(self, columns: Sequence[int]) -> ModelMetrics:
        data = self._data
        k = len(columns)

        if k == 0 or k >= data.n_train - self.SPARE_MOLECULES:
            return ModelMetrics.invalid(k)

        X_train = data.X_train[:, columns]
        leverage = self._leverage(X_train)
        if leverage is None:
            return ModelMetrics.invalid(k)

        model = LinearRegression().fit(X_train, data.y_train)
        pred_train = model.predict(X_train)
        pred_valid = model.predict(data.X_valid[:, columns])
        pred_test = model.predict(data.X_test[:, columns])

        # Q2 by the leave-one-out shortcut (exact for linear regression):
        #   error of molecule i when it is left out = residual_i / (1 - leverage_i)
        # so we do not need to refit the model once per training molecule.
        residual = data.y_train - pred_train
        press = np.sum((residual / (1.0 - leverage)) ** 2)
        total = np.sum((data.y_train - data.y_train.mean()) ** 2)
        q2_train = 1.0 - press / total
        rmse_cv_train = np.sqrt(press / data.n_train)

        r2_train = r2_score(data.y_train, pred_train)
        r2_valid = r2_score(data.y_valid, pred_valid)
        r2_test = r2_score(data.y_test, pred_test)

        rmse_train = np.sqrt(mean_squared_error(data.y_train, pred_train))
        rmse_valid = np.sqrt(mean_squared_error(data.y_valid, pred_valid))
        rmse_test = np.sqrt(mean_squared_error(data.y_test, pred_test))

        return ModelMetrics(
            n_features=k,
            r2_train=r2_train, q2_train=q2_train,
            r2_valid=r2_valid, r2_test=r2_test,
            rmse_train=rmse_train, rmse_cv_train=rmse_cv_train,
            rmse_valid=rmse_valid, rmse_test=rmse_test,
            fitness=self._fitness(rmse_cv_train, rmse_valid),
            passes=self._passes(r2_train, q2_train, r2_valid, r2_test),
        )

    def fit(self, columns: Sequence[int]) -> LinearRegression:
        """Fit the final regression on the training molecules."""
        return LinearRegression().fit(self._data.X_train[:, columns], self._data.y_train)

    # ------------------------------------------------------------------
    def _leverage(self, X: np.ndarray) -> np.ndarray | None:
        """How strongly each molecule pulls the fitted line towards itself.

        Computed from the SVD of the centred descriptors. Returns None when the
        model is not well defined (two descriptors perfectly correlated, or a
        molecule with leverage 1).
        """
        n, k = X.shape
        U, S, _ = np.linalg.svd(X - X.mean(axis=0), full_matrices=False)

        rank = int(np.sum(S > S.max() * self.RANK_TOLERANCE))
        if rank < k:
            return None

        leverage = 1.0 / n + np.sum(U[:, :k] ** 2, axis=1)
        if np.any(1.0 - leverage < self.LEVERAGE_TOLERANCE):
            return None
        return leverage

    def _fitness(self, rmse_cv_train: float, rmse_valid: float) -> float:
        mode = self._config.fitness_mode
        if mode is FitnessMode.CV_TRAIN:
            return rmse_cv_train
        if mode is FitnessMode.VALID:
            return rmse_valid
        return 0.5 * (rmse_cv_train + rmse_valid)       # TRAIN_VALID

    def _passes(self, *r2_values: float) -> bool:
        """Professor's rule: every value >= r2_min and < r2_max."""
        low, high = self._config.r2_min, self._config.r2_max
        return all(low <= v < high for v in r2_values)
